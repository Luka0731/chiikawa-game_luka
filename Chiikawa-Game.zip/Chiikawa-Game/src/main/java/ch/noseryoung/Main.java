package ch.noseryoung;

import ch.noseryoung.chiikawagameengine.Window;

public class Main   {
    public static void main(String[] args) {
        Window window = Window.getWindow();
        window.run();
    }
}